# rtl_streaming_v0.2 + SystemVerilog verification package

This package adds a plain-SystemVerilog verification environment around the clean-room
`rtl_streaming_v0.2` core. The environment is organized around the MATLAB artifacts of
record rather than a reimplementation of the DWT equations inside the testbench.

Read in this order:

1. `docs/TEST_ENVIRONMENT.md` — architecture of the verification environment, drivers,
   monitors, scoreboards, golden-file contract, checkpoint shadow, and pass semantics.
2. `docs/TEST_PLAN.md` — testcase matrix T00–T21, acceptance criteria, size ladder, and
   regression gates.
3. `tb/*.sv` — executable testbenches.
4. `vectors/README.md` — where the retained MATLAB vector directories are placed.

Main testbenches:

- `tb_dwt53_fwd1d_pair_stream.sv` — atomic forward lifting against MATLAB L/H files.
- `tb_dwt53_fwd2d_stream.sv` — Forward 2-D Level 1 or Level 2 against packed C1/C2.
- `tb_dwt53_inv2d_stream.sv` — inverse Level 2 to LL1 and inverse Level 1 to Y8.
- `tb_dwt53_checkpoint8.sv` — independent directed test of count/xor/A/B recurrence.
- `tb_dwt53_streaming_top.sv` — main stage-by-stage and end-to-end golden regression.
- `tb_dwt53_streaming_protocol.sv` — malformed framing tests.
- `tb_dwt53_streaming_c0c2.sv` — checkpoint-disabled/enabled datapath equivalence.
- `tb_dwt53_streaming_two_frames.sv` — frame restart/atomicity.

Important evidence status: these TB sources have been statically reviewed in the current
workspace, but no Verilator/Icarus executable is installed here, so **no simulator PASS is
claimed by this package**. Actual compile/elaboration is T00 and must be the first run on the
project machine.

Known pre-run finding: the v0.2 inverse primitive requires `SUB_W,SUB_H >= 2`. Therefore a
mathematically valid two-level 4x4 frame reaches a 1x1 Level-2 inverse subband and currently
fails that parameter check. The test plan intentionally preserves this as T08. It does not
affect 1280x720, whose Level-2 subbands are 320x180.
