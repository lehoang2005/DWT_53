# RTL Streaming Test Environment

## 1. Purpose

This environment verifies `rtl_streaming_v0.2` directly against the frozen MATLAB
integer golden artifacts. It does not use the buffered RTL as a design source.

The environment is intentionally lightweight and simulator-portable: plain
SystemVerilog drivers, monitors, scoreboards, assertions/checkers, and `$readmemh`
files. No UVM, DPI, vendor PLI, or proprietary verification library is required.

## 2. Verification architecture

```text
                  MATLAB golden model
                         |
                         | committed HEX artifacts
                         v
+---------------------------------------------------------------+
|                    SystemVerilog testbench                     |
|                                                               |
|  stimulus driver --> DUT rtl_streaming_v0.2 --> output monitor|
|         |                   |   |   |   |             |        |
|         |                   |   |   |   |             |        |
|         |                 L1   L2  RC  RE             |        |
|         |                   \   |   |   /              |        |
|         +---------------------> scoreboards <----------+        |
|                                |                              |
|                         protocol/error checks                 |
|                                |                              |
|                         checkpoint shadow model               |
+---------------------------------------------------------------+
                         |
                         v
                   PASS / FAIL report
```

The top-level regression observes these logical points:

- input Y8 stream / `CP-IN`;
- forward Level-1 quartet stream, reconstructed into packed `C1`;
- forward Level-2 quartet stream plus untouched Level-1 high bands,
  reconstructed into packed `C2`;
- inverse Level-2 reconstructed `LL1` / `CP-RC`;
- inverse Level-1 reconstructed samples / `CP-RE`;
- external Y8 output stream.

The stage monitors use simulation-only hierarchical observation of internal top-level
signals (`l1_*`, `l2_*`, `rc_*`, `re_*`). No DUT datapath signal is driven or changed by
the monitors.

## 3. Golden vector contract

The 2-D/top testbenches expect one vector directory containing:

```text
input_y8_hex.txt
c1_packed_hex.txt
c2_packed_hex.txt
recon_y8_hex.txt
manifest.txt                 # informative; TB does not parse it
```

The file meanings are:

- `input_y8_hex.txt`: unsigned Y8, 2 hex digits/sample, row-major;
- `c1_packed_hex.txt`: signed 16-bit two's-complement packed C1, row-major;
- `c2_packed_hex.txt`: signed 16-bit two's-complement packed C2, row-major;
- `recon_y8_hex.txt`: unsigned Y8, row-major; must equal the input exactly.

Packed one-level layout:

```text
+------+------+
|  LL  |  HL  |
+------+------+
|  LH  |  HH  |
+------+------+
```

The two-level packed plane replaces only the `LL1` quadrant by
`[LL2 HL2; LH2 HH2]`.

For 1-D tests, the vector directory contains:

```text
input_hex.txt
L_hex.txt
H_hex.txt
```

All three are interpreted as signed two's-complement. A Y8-mode input file with two
hex digits also loads correctly into the 16-bit testbench input memory.

## 4. Driver model

### 4.1 Top-level driver

The driver waits for `frame_ready`, then sends exactly `WIDTH*HEIGHT` samples.
For accepted pixel `(x,y)`:

```text
in_sof = (x==0 && y==0)
in_eol = (x==WIDTH-1)
in_eof = (x==WIDTH-1 && y==HEIGHT-1)
```

Default regression uses one accepted sample per clock. `+GAP_EVERY=N` optionally
inserts one invalid clock before each Nth sample to verify that valid gaps do not
change arithmetic, ordering, or frame-marker accounting.

There is no pixel-level `ready`; once a frame starts, the stimulus never waits for
the DUT.

### 4.2 Unit drivers

- Forward-1D: one vector sample per valid clock, explicit `in_sov/in_eov`.
- Forward-2D: raster input, explicit SOF/EOL/EOF.
- Inverse-2D: one parallel `{LL,HL,LH,HH}` coordinate per valid clock.

## 5. Monitors and scoreboards

### 5.1 C1 scoreboard

Each Level-1 output event contains one logical subband coordinate `(sx,sy)` and four
samples. The scoreboard maps them into the packed full-plane positions and compares
each sample against `c1_packed_hex.txt`.

### 5.2 C2 scoreboard

`C2` is checked without requiring a physical C2 frame inside the DUT:

- every `HL1/LH1/HH1` value is compared at its unchanged packed C2 position;
- every Level-2 `LL2/HL2/LH2/HH2` value is compared inside the top-left quadrant.

Thus exactly `WIDTH*HEIGHT` C2 coefficients are checked even though no complete C2
plane exists in the streaming architecture.

### 5.3 Reconstructed LL1 scoreboard

The inverse-Level-2 stream is row-major `LL1_rec` of dimensions
`WIDTH/2 x HEIGHT/2`. Every sample is compared against the top-left LL1 quadrant of
`C1`.

### 5.4 Reconstructed image scoreboard

Both the internal `re_sample` and external `out_y` streams are compared against
`recon_y8_hex.txt`; because the transform is reversible, that file must also equal
`input_y8_hex.txt`.

## 6. Checkpoint verification

The top TB maintains an independent SystemVerilog shadow of the frozen recurrence:

```text
count = count + 1
xor   = xor XOR pattern(v)
A     = A + contribution(v)          mod 2^32
B     = B + A_new                    mod 2^32
```

For `CP-L1`, the expected B order is the documented streaming order:
`LL1, HL1, LH1, HH1` at each logical coordinate.

For `CP-FW`, the TB follows the DUT's documented chronological merge: on a clock where
both source streams are valid, Level-1 high bands are added first
`HL1,LH1,HH1`, followed by `LL2,HL2,LH2,HH2`.

The TB checks all four snapshot fields for the implemented emission order. This is a
strong RTL semantic check, but it is not a substitute for the planned MATLAB
`signatures.txt` artifact; final project acceptance should also compare the same
snapshots against MATLAB-generated checkpoint signatures once that exporter is in the
golden package.

## 7. Error and protocol checks

A fault-free regression requires all sticky DUT errors to remain zero:

```text
range_error      == 0
arithmetic_error == 0
buffer_error     == 0
protocol_error   == 0
```

The dedicated protocol TB deliberately violates framing and requires
`protocol_error` to assert. It does not define recovery semantics for short/long
frames because that policy is still an open system-spec item.

## 8. Timing/throughput observations

The testbench records, but does not invent a hardware frequency for:

- first-input to first-output latency in core clocks;
- total frame latency in core clocks;
- maximum gap between output-valid samples after output starts;
- maximum observed Level-1 detail-alignment FIFO occupancy.

Hardware MHz, microseconds, and 720p60 pass/fail belong to synthesis/STA and board
measurement after the core-clock frequency is frozen.

## 9. Testbench hierarchy

```text
tb_dwt53_fwd1d_pair_stream.sv    atomic 1-D forward lifting

tb_dwt53_fwd2d_stream.sv         one-level forward 2-D; LEVEL=1 or 2

tb_dwt53_inv2d_stream.sv         one-level inverse 2-D; LEVEL=1 or 2

tb_dwt53_checkpoint8.sv          standalone checkpoint recurrence/lane order

tb_dwt53_streaming_top.sv        main bit-exact stage + top regression

tb_dwt53_streaming_protocol.sv   negative framing tests

tb_dwt53_streaming_c0c2.sv       checkpoints disabled/enabled datapath equivalence

tb_dwt53_streaming_two_frames.sv  frame-atomic restart / second accepted frame
```

## 10. Known parameterization corner before simulation

While constructing the environment, one DUT constraint became visible: the current
`dwt53_inv2d_stream` requires each input subband dimension to be at least 2. A 4x4
two-level image produces 1x1 Level-2 subbands, so the 4x4 full-top test is retained as
a compliance test but is expected to fail until that RTL corner is implemented. The
720p target is unaffected.

## 11. Pass definition

A testcase PASS means every checker enabled for that testcase passed and the TB reached
normal completion. Compile-only, small-size PASS, full-size PASS, and hardware PASS are
separate evidence levels and must not be conflated.
