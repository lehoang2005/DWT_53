# rtl_streaming v0.2 Verification Test Plan

## 1. Verification goals

The test plan answers five questions in order:

1. Is the atomic reversible 5/3 arithmetic correct, including negative rounding and boundaries?
2. Is row/column scheduling correct for one 2-D level?
3. Is Level-2-only-on-LL1 routing and inverse order correct?
4. Does the complete streaming pipeline reproduce MATLAB C1, C2, reconstructed LL1, and Y8 bit-exactly without buffer/protocol errors?
5. Do validation checkpoints observe the intended streams without changing the datapath?

## 2. Test matrix

| ID | Test | DUT / TB | Stimulus | Main checks | Expected |
|---|---|---|---|---|---|
| T00 | Compile/elaborate | all RTL + all TBs | none | syntax, parameters, hierarchy | PASS |
| T01 | Forward-1D golden | `dwt53_fwd1d_pair_stream` | MATLAB `input/L/H` | every L/H pair, SOV/EOV, errors | zero mismatch |
| T02 | Forward-1D with valid gaps | same | same + periodic gaps | outputs unchanged; no protocol error | zero mismatch |
| T03 | Forward-2D L1 | `dwt53_fwd2d_stream`, LEVEL=1 | `input_y8` | LL/HL/LH/HH mapped to C1 | zero mismatch |
| T04 | Forward-2D L2 | same, LEVEL=2 | LL1 extracted from C1 | Level-2 quartet mapped into C2 top-left | zero mismatch |
| T05 | Inverse-2D L2 | `dwt53_inv2d_stream`, LEVEL=2 | C2 Level-2 quadrants | reconstructed LL1 vs C1 LL1 | zero mismatch |
| T06 | Inverse-2D L1 | same, LEVEL=1 | C1 quadrants | reconstructed Y8 vs golden | zero mismatch |
| T07 | Checkpoint lane recurrence | `dwt53_checkpoint8` | directed multi-lane signed samples | count/xor/A/B including frame-end cycle | exact |
| T08 | Minimum-size compliance | `dwt53_streaming_top` | 4x4 canonical ramp | parameterization and 1x1 Level-2 inverse corner | **KNOWN v0.2 ISSUE** until fixed |
| T09 | Full top random small | same | 8x8, 8x12, 12x8, 16x16 | same | all pass |
| T10 | Orientation trap | same | 8x12 + 12x8 + edge frame | row/column and subband placement | all pass |
| T11 | Medium regression | same | 64x64, 64x128, 128x256 | exact stages + buffer occupancy | all pass |
| T12 | Pre-full rehearsal | same | 256x512 | exact stages + latency cycles | all pass |
| T13 | Full random 720p | same | random 720x1280 | 921600 C1/C2 coefficients, LL1, Y8 | all pass |
| T14 | Full natural 720p | same | real 720x1280 frame | same | all pass |
| T15 | Input valid gaps | full top | representative 16x16/64x64 + gaps | accepted-sample semantics, exact output | all pass |
| T16 | Back-to-back accepted frames | full top | second frame only after `frame_ready` | frame atomicity | all pass |
| T17 | Bad framing: no SOF | protocol TB | valid sample while idle, no SOF | `protocol_error` | assert |
| T18 | Bad framing: duplicate SOF | protocol TB | SOF inside active frame | `protocol_error` | assert |
| T19 | Bad EOL | protocol TB | EOL at wrong x | `protocol_error` | assert |
| T20 | Bad EOF | protocol TB | EOF at wrong coordinate | `protocol_error` | assert |
| T21 | C0 vs C2 equivalence | dual top | same golden input | cycle-exact Y8/markers/errors | identical |

## 3. Golden size ladder

Use the retained MATLAB generator's ladder in this order:

```text
canonical_0004x0004
random_0008x0008
random_0008x0012
random_0012x0008
random_0016x0016
edges_0016x0016
random_0064x0064
random_0064x0128
random_0128x0256
random_0256x0512
random_0720x1280       # opt-in full size
real_0720x1280         # opt-in full size
```

Remember that names are `rows x cols`, while DUT parameters are
`HEIGHT=rows`, `WIDTH=cols`.


## 3.1 Known pre-run DUT finding exposed while designing the TB

The frozen algorithm permits any two-level image whose dimensions are divisible by 4,
so 4x4 is mathematically valid. The current `rtl_streaming_v0.2` inverse primitive,
however, contains an elaboration-time requirement `SUB_W >= 2 && SUB_H >= 2`. At the
second level of a 4x4 image, each subband is 1x1, so T08 currently exposes a genuine
parameterization gap.

This does **not** affect the 1280x720 target (Level-2 subbands are 320x180), but the
4x4 test remains in the plan so the limitation cannot be silently forgotten. The
first fault-free full-top regression expected to pass with v0.2 is therefore 8x8.

## 4. Detailed acceptance criteria

### 4.1 Arithmetic / coefficients

- Forward-1D L/H mismatch count = 0.
- C1 mismatch count = 0 over exactly `WIDTH*HEIGHT` coefficients.
- C2 mismatch count = 0 over exactly `WIDTH*HEIGHT` coefficients.
- Reconstructed LL1 mismatch count = 0 over exactly `WIDTH*HEIGHT/4` samples.
- Final Y8 mismatch count = 0 over exactly `WIDTH*HEIGHT` samples.
- Maximum reconstruction error = 0.

### 4.2 Ordering / framing

For every logical stream:

- first valid sample has SOF only;
- EOL occurs exactly at the final sample of each row;
- EOF occurs exactly at the last sample of the frame;
- sample count is exact;
- no duplicate or missing logical coordinate.

### 4.3 Error flags

For all positive tests:

```text
range_error      = 0
arithmetic_error = 0
buffer_error     = 0
protocol_error   = 0
```

For directed negative framing tests, only `protocol_error=1` is required. The test
resets between negative cases because the error is sticky.

### 4.4 Checkpoints

Expected snapshot counts:

```text
CP-IN  = WIDTH*HEIGHT
CP-L1  = WIDTH*HEIGHT
CP-FW  = WIDTH*HEIGHT
CP-RC  = WIDTH*HEIGHT/4
CP-RE  = WIDTH*HEIGHT
```

All count/xor/A/B fields must match the TB shadow for the documented streaming
emission order. `CP-IN` and `CP-RE` must also match each other for the fault-free
round trip.

### 4.5 Buffer schedule

- alignment FIFO overflow = 0;
- alignment FIFO underflow = 0;
- inverse ping-pong buffer error = 0;
- report maximum `u_band_align.count_q` occupancy;
- final measured occupancy must remain below configured depth for every size,
  especially both 720p frames.

### 4.6 Configuration equivalence

With identical stimulus:

```text
CHECKPOINT_EN=0 output == CHECKPOINT_EN=1 output
```

The comparison is cycle-exact for `out_valid/out_y/out_sof/out_eol/out_eof` and
for datapath error flags.

## 5. Tests intentionally deferred from this TB drop

These remain required by the research plan but are not mixed into the first datapath
bring-up suite:

1. fault-injection/localization matrix (`F-BIT`, `F-VAL`, drop/dup, permutations,
   self-cancelling faults);
2. MATLAB `signatures.txt` checkpoint artifact comparison once
   `export_checkpoint_signatures.m` is committed and frozen;
3. synthesis proof of DSP=0, M10K inference, resource use, and Fmax;
4. physical camera/HDMI tests and measured transform/end-to-end latency;
5. phase-2 DE10-HAPS link/CDC/sideband tests.

The fault-injection suite should start only after T00-T21 fault-free regressions are
stable, otherwise injected-fault failures are ambiguous with ordinary datapath bugs.

## 6. Recommended regression gates

```text
Gate TB-A: T00 + T01 + T03 + T05 + T07
           Atomic blocks compile and match golden.

Gate TB-B0: T08
            Spec-minimum 4x4 compliance check. v0.2 is expected to expose the
            current inverse-core SUB_W/SUB_H>=2 limitation; this is a DUT finding,
            not a waived test.

Gate TB-B: T09 + T10
           Full streaming topology works on supported small diagnostic frames (>=8x8).

Gate TB-C: T11 + T12 + T15 + T21
           Schedule/buffer behavior is stable at useful scale and C0=C2.

Gate TB-D: T13 + T14
           Full 1280x720 bit-exact regression passes on synthetic and natural frames.

Gate TB-E: fault-injection package (separate drop)
           Stage-localization evidence for the paper.
```
